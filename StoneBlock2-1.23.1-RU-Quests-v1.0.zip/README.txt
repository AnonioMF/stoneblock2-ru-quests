=====================================================================
 FTB Presents StoneBlock 2 — русский перевод квестов
 Версия перевода: 1.0     Для сборки: StoneBlock 2 1.23.1 (MC 1.12.2)
=====================================================================

ЧТО ПЕРЕВЕДЕНО
  Все квесты из книги квестов (FTB Quests): названия, подзаголовки,
  описания, названия глав, таблиц наград и лутбоксов — 634 строки.
  Названия модов (Thaumcraft, ProjectE, Draconic Evolution и т.д.)
  оставлены как есть. Баланс, награды и шансы НЕ изменены.

  Предметы и интерфейс модов переводятся самим Minecraft:
  выберите в игре Настройки -> Язык -> Русский.

УСТАНОВКА
  1. Закройте игру.
  2. Откройте папку сборки:
     FTB App: правой кнопкой по сборке -> Open Folder
     (обычно %LOCALAPPDATA%\.ftba\instances\ftb presents stoneblock 2)
  3. Сделайте копию папки config\ftbquests на случай отката.
  4. Скопируйте папку config из архива в папку сборки с заменой файлов.
  5. Запустите игру.

  Работает и в уже созданном мире: прогресс квестов не сбрасывается,
  потому что ID квестов не менялись.

ВАЖНО
  - Если сборка обновится, лаунчер может вернуть английские квесты —
    просто установите перевод заново.
  - Для другой версии сборки файлы могут не подойти.
  - Если вы правите квесты в игре в режиме редактирования, мод
    перезапишет файлы — это нормально.

ОТКАТ
  Верните сохранённую копию config\ftbquests или переустановите сборку.

ОБ АВТОРСТВЕ
  StoneBlock 2 и все квесты принадлежат команде Feed The Beast.
  Архив содержит только файлы квестов, ни одного мода.

---------------------------------------------------------------------
 ENGLISH
---------------------------------------------------------------------
 Russian translation of all FTB Quests in FTB Presents StoneBlock 2
 (pack version 1.23.1, Minecraft 1.12.2). 634 strings: quest titles,
 subtitles, descriptions, chapters, reward tables and loot crates.
 Balance and rewards are unchanged.

 Install: close the game, back up config/ftbquests in the instance
 folder, copy the config folder from this archive over it, replacing
 files. Existing worlds keep their quest progress (IDs are unchanged).

 Translation made with AI assistance (Claude); report mistakes in
 the comments. StoneBlock 2 and its quests belong to Feed The Beast.
 This archive contains quest files only, no mods.
